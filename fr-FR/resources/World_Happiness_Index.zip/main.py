#!/bin/python3
from pygal import *

# Create a chart
#chart = Bar()
#chart.title = 'World Happiness Index 2019 test'

# Add data to the chart
with open('WHI_2019.csv') as f:
  data = f.read()
  lines = data.splitlines()

choice = 0

def main():
  print('World Happiness Index Data 2019')
  
  choice = input('What would you like to see? \n1. How happy are countries overall? \n2. How much does national wealth matter? \n3. How well does your country look after the disadvantaged? \n4.How generous are people? \n5. How fair and honest are people? \n6. How much freedom do you have? \nChoice:')
  
  if choice == '1':
    chart = Bar(width=800)
    chart.title = 'World Happiness Index 2019 - Scores'
    for line in lines:
      whi = line.split(',')
      country = whi[1]
      score = whi[2]
      chart.add(country, float(score))
    chart.render()
    main()
  
  elif choice == '2':
    chart = Pie()
    chart.title = 'World Happiness Index 2019 - Gross Domestic Product'
    for line in lines:
      whi = line.split(',')
      rank = whi[0]
      country = whi[1]
      gdp  = whi[3]
      chart.add(country, float(gdp))
    chart.render()
    main()
  
  elif choice == '3':
    chart = Bar(width=800)
    chart.title = 'World Happiness Index 2019 - Social Support'
    for line in lines:
      whi = line.split(',')
      country = whi[1]
      support  = whi[4]
      chart.add(country, float(support))
    chart.render()
    main()
  
  elif choice == '4':
    chart = Bar(width=800)
    chart.title = 'World Happiness Index 2019 - Generosity'
    for line in lines:
      whi = line.split(',')
      country = whi[1]
      generous  = whi[7]
      chart.add(country, float(generous))
    chart.render()
    main()
  
  elif choice == '5':
    chart = Pie()
    chart.title = 'World Happiness Index 2019 - Corruption'
    for line in lines:
      whi = line.split(',')
      country = whi[1]
      corrupt  = whi[8]  
      chart.add(country, float(corrupt))
    chart.render()
    main()
  
  elif choice == '6':
    chart = Pie()
    chart.title = 'World Happiness Index 2019 - Freedom'
    for line in lines:
      whi = line.split(',')
      country = whi[1]
      freedom  = whi[6]
      chart.add(country, float(freedom))
    chart.render()
    main()
    
main()